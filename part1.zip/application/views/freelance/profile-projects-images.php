<div class="container mt-5">
	<title>Upload Images</title>
	<hr>
	

	<?php echo form_open_multipart('users/do_upload');?>

	<input type="file" name="userfile" size="20" />

	<?php
		if(isset($error))
		{
			echo $error;
		}

	;?>
	<br /><br />

	<input type="submit" class="btn btn-primary-outline" value="upload" /></form>

	<hr>

	
</div>