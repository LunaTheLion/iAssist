<title>Messages | List</title>
<a href="<?php echo base_url('messaging/compose') ?>">Compose</a>
<a href="<?php echo base_url('messaging/inbox') ?>">Inbox</a>
<a href="<?php echo base_url('messaging/sent') ?>">Sent</a>
<a href="<?php echo base_url('messaging/trash') ?>">Trash</a>