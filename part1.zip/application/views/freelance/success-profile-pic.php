<div class="container">
	
	   <img  class="img-circle" src="<?php echo $img?>" width="340" height="310">
	   <a href="<?php echo base_url('users/profile/'.$this->session->userdata('user_name'))?>" class="btn btn-success">Done</a>
</div>