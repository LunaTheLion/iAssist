<div class="jumbotron">
	<div class="container">
		<p class="text-primary text-center">You successfully Signed in!
		<br>
		We have sent confirmation email to to your email, Please access your account.</p>
		<br>
		<div class="row">
			<div class="col-lg-4"></div>
			<div class="col-lg-4">
				<a href="<?php echo base_url('admin/create_profile');?>" class="btn btn-outline-primary btn-block">Click here to Create Profile</a>
			</div>
			<div class="col-lg-4"></div>
		</div>
		
	</div>	 

</div>