<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['MAX_INPUT_LENGTHS'] = array(
	PM_RECIPIENTS => 200,
	TF_PM_SUBJECT => 100
);

/* End of file Pm.php */
