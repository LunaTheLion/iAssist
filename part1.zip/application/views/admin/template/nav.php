<nav class="navbar-default navbar-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav" id="main-menu">

            <li>
                <a href="<?php echo base_url('admin/dashboard'); ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
            </li> 
            <!-- <li>
                <a class="<?php echo $active_applicant; ?>" href="<?php echo base_url('admin/applicant'); ?>"><i class="fa fa-briefcase"></i> Applicant</a>
            </li>
            <li>
                <a class="<?php echo $active_company; ?>" href="<?php echo base_url('admin/company'); ?>"><i class="fa fa-building-o"></i> Company <span class="badge"></span></a>
            </li>
        class="<?php echo $active_job; ?>" href="<?php echo base_url('admin/job'); ?>"-->
             <li>
                <a href="<?php echo base_url('admin/projects'); ?>"><i class="fa fa-tasks"></i>Projects <span class="badge"></span></a>
            </li>
            
             <li>
                <a><i class="fa fa-fw fa-file"></i> Reports<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php  ?>">Daily Report</a>
                    </li>
                    <li>
                        <a href="<?php  ?>">Weekly Report</a>
                    </li>
                    <li>
                        <a href="<?php  ?>">Monthly Report</a>
                    </li>
                    <li>
                        <a href="<?php  ?>">Quarterly Report</a>
                    </li>
                    <li>
                        <a href="<?php  ?>">Yearly Report</a>
                    </li>
                </ul>
            </li>
           
        </ul>

    </div>

</nav>
<!-- /. NAV SIDE  -->