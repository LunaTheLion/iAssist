<div class="container mt-5">

	
	
	<br>
		<div class="row">
		<div class="col-lg-3">
		</div>
		<div class="col-lg-6">
			<h2>Setup your package</h2>
			<h6>Write down your offered services!</h6>
			
			<div class="form-group">
			      <label for="title">Write your Offer</label>
			      <textarea class="form-control" id="title" rows="3"  style="font-size: 44pt"></textarea>
			    </div>

			<div class="form-group">
			      <label for="category">Category</label>
			      <select class="form-control" id="category">
			        <option>Digital Marketing</option>
			        <option>Writing and Translation</option>
			        <option>Video and Animation</option>
			        <option>Music and Audio</option>
			        <option>Programming and Tech Business</option>
			        <option>Fun and Lifestyle</option>
			      </select>
			    </div>


				<br><br>		
			<div class="row">
				<div class="col-lg-3"></div>
				<div class="col-lg-3">
					<a class="btn btn-primary btn-outline btn-block" href="javascript:window.history.go(-1);">Back</a>
				</div>
				<div class="col-lg-3">
					<a class="btn btn-success btn-outline btn-block" href="<?php echo base_url('users/index')?>">Next</a>
				</div>
				<div class="col-lg-3"></div>
			</div>			
		</div>
		<div class="col-lg-3">			
		</div>
	</div>
</div>